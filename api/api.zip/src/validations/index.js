module.exports.userValidation = require("./user.validation");
module.exports.orderValidation = require("./orders.validation");
module.exports.branchValidation = require("./branch.validation");
module.exports.paymentValidation = require("./payment.validation");
module.exports.notificationValidation = require("./notification.validation");
module.exports.expenseValidation = require("./expense.validation");
module.exports.analysisValidation = require("./analysis.validation");
